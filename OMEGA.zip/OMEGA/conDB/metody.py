from conDB import connection

class ProblemDB(Exception):
    def __init__(self, mes):
        self.mes = mes

def nacteniAut():
    c = connection.Connection()
    con = c.con()
    cursor = con.cursor()
    sql = "select * from auto order by id;"
    cursor.execute(sql)
    myresult = cursor.fetchall()
    cursor.close()
    lis = []
    for i in myresult:
        lis.append(i[1])
    return lis

def metoda1(ob : object, ob2 : object):
    for i in ob:
        ob2.addItem("")

def getIdModelu(model, con):
    try:
        cursor = con.cursor()
        sql = "select id from auto where model = '"+model+"';"
        cursor.execute(sql)
        myresult = cursor.fetchall()
        cursor.close()
        lis = []
        for i in myresult:
            lis.append(i[0])
        return lis[0]
    except Exception:
        raise ProblemDB('Problem s DB')

def getIdAutoservisu(autoservis, con):
    try:
        cursor = con.cursor()
        sql = "select id from autoservisy where concat(nazev,' ',mesto) = '"+autoservis+"';"
        cursor.execute(sql)
        myresult = cursor.fetchall()
        cursor.close()
        lis = []
        for i in myresult:
            lis.append(i[0])
        return lis[0]
    except Exception:
        raise ProblemDB('Problem s DB')

def getGlobalIdAutoservisu(autoservis, con):
    try:
        cursor = con.cursor()
        sql = "select global_id from autoservisy where concat(nazev,' ',mesto) = '"+autoservis+"';"
        cursor.execute(sql)
        myresult = cursor.fetchall()
        cursor.close()
        lis = []
        for i in myresult:
            lis.append(i[0])
        return lis[0]
    except Exception:
        raise ProblemDB('Problem s DB')

def getIdUzivatele(email, con):
    try:
        cursor = con.cursor()
        sql = "select id from user where email = '"+email+"';"
        cursor.execute(sql)
        myresult = cursor.fetchall()
        cursor.close()
        lis = []
        for i in myresult:
            lis.append(i[0])
        return lis[0]
    except Exception:
        raise ProblemDB('Problem s DB')
